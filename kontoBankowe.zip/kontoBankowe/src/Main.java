
public class Main {

    Klient klient1 = new Klient("Michal Wedzina", 1,  "Zeromskiego 29");
    Klient klient2 = new Klient("Marek Kowalski", 2, "Mysliborska 20");
    Klient klient3 = new Klient("Robert Mostowiak", 3, "Gorzowska 3");

    KontoBankowe konto1 = new KontoBankowe(54321, 125, klient1);
    KontoBankowe konto2 = new KontoBankowe(12345, 50, klient2 );
    KontoBankowe konto3 = new KontoBankowe(13579, 20, klient3);



    public class Klient{
        private String nazwaKlienta;
        private int idKlienta;
        private String adresKlienta;

        public Klient(String nazwaKlienta, int idKlienta, String adresKlienta) {
            this.nazwaKlienta = nazwaKlienta;
            this.idKlienta = idKlienta;
            this.adresKlienta = adresKlienta;
        }
        public void wyswietlInformacjeOKliencie(){
            System.out.println("Nazwa: " + nazwaKlienta);
            System.out.println("ID: " + idKlienta);
            System.out.println("Adres: " + adresKlienta);
        }
        public void setNazwaKlienta(String nazwaKlienta){
            this.nazwaKlienta = nazwaKlienta;
        }
        public void setAdresKlienta(String adresKlienta){
            this.adresKlienta = adresKlienta;
        }
        public void setIdKlienta(int idKlienta){
            this.idKlienta = idKlienta;
        }

    }

    public class KontoBankowe{
        private int numerKonta;
        private int saldoKonta;
        private Klient informacje;

        public KontoBankowe(int numerKonta, int saldoKonta, Klient informacje) {
            this.numerKonta = numerKonta;
            this.saldoKonta = saldoKonta;
            this.informacje = informacje;
        }
        public void wplacPieniadze(int kwota){
            if(kwota > 0){
                saldoKonta += kwota;
                System.out.println("Wplacono " + kwota + " zł na Twoje konto");
            } else{
                System.out.println("Odmowa dostepu. Sprawdz ponownie pozniej");
            }

        }
        public void wyplacPieniadze(int kwota){
            if (kwota < saldoKonta){
                saldoKonta -= kwota;
                System.out.println("Wyplaciles " + kwota + " zł z Twojego konta");
            } else {
                System.out.println("Nie masz tyle srodkow na koncie");
            }
        }
        public void wyswietlSaldo(){
            System.out.println("Saldo konta wynosi: " + saldoKonta);
        }


    }
}