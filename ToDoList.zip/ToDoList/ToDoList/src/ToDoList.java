import java.util.ArrayList;
import java.util.Scanner;

public class ToDoList {

    public static class zadanie {
        String tytulZadania;
        String opisZadania;
        boolean status;

        public zadanie(String tytulZadania, String opisZadania, boolean status){
            this.tytulZadania = tytulZadania;
            this.opisZadania = opisZadania;
            this.status = false;
        }

        public String getTytulZadania() {
            return tytulZadania;
        }

        public String getOpisZadania() {
            return opisZadania;
        }

        public boolean status() {
            return status;
        }

        public void wykonane(boolean status) {
            this.status = status;
        }
    }

    public static void main(String[] args){
        ArrayList<zadanie> listaZadan = new ArrayList<>();

        Scanner scanner = new Scanner(System.in);

        int menu;

        do {
            System.out.println("Menu uzytkownika: ");
            System.out.println("1. Dodaj nowe zadanie");
            System.out.println("2. Oznacz zadanie jako ukonczone");
            System.out.println("3. Usun zadanie");
            System.out.println("4. Wyswietl liste zadan");
            System.out.println("5. Wyjscie");

            menu = scanner.nextInt();

            switch (menu){
                case 1:
                    System.out.println("Podaj tytul zadania: ");
                    String tytulZadania = scanner.nextLine();
                    System.out.println("Podaj opis zadania: ");
                    String opisZadania = scanner.nextLine();
                    zadanie noweZadanie = new zadanie(tytulZadania, opisZadania, false);
                    listaZadan.add(noweZadanie);
                    System.out.println("Zadanie dodano pomyslnie");

                    break;
                case 2:
                    dodajZadanie();

                    break;
                case 3:
                    oznaczWykonane();
                    break;
                case 4:
                    wyswietlZadania();

                    break;
                case 5:
                    System.out.println("Wyszedles");

                    break;
                default: System.out.println("Nieprawidlowy wybor. Sproboj ponownie.");
            }
        } while (menu!=5);

        scanner.close();

        private static void dodajZadanie() {
            System.out.print("Podaj nazwe zadania: ");
            String name = scanner.next();
            System.out.print("Podaj opis zadania: ");
            String description = scanner.next();

            zadanie noweZadanie = new zadanie(tytulZadania, opisZadania);
            listaZadan.add(noweZadanie);

            System.out.println("Dodano zadanie");
        }

        private static void oznaczWykonane() {
            oznaczWykonane();
            System.out.print("Podaj numer zadania ktore ukonczyles:  ");
            int numerZadania = scanner.nextInt();

            if (numerZadania >= 1 && numerZadania <= listaZadan.size()) {
                zadanie zadanie = listaZadan.get(numerZadania - 1);
                zadanie.status(true);
                System.out.println("Zadanie zakonczone");
            } else {
                System.out.println("Niepoprawny numer zadania.");
            }
        }
        private static void wyswietlZadania() {
            System.out.println("Lista zadań:");
            for (int i = 0; i < listaZadan.size(); i++) {
                zadanie task = listaZadan.get(i);
                System.out.println((i + 1) + ". " + task.getTytulZadania() + " - " + task.getOpisZadania()
                        + " - " + (task.status() ? "Zakończone" : "Nie zakończone"));
            }
            System.out.println();
        }

    }
}
