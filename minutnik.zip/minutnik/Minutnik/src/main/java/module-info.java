module com.example.minutnik {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.minutnik to javafx.fxml;
    exports com.example.minutnik;
}