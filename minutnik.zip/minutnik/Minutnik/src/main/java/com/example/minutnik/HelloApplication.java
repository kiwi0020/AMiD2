package com.example.minutnik;

import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;

public class HelloApplication extends Application {

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage stronaGlowna) {
        stronaGlowna.setTitle("Odliczanie do nowego roku");

        StackPane root = new StackPane();
        Label odliczanieLabel = new Label();
        root.getChildren().add(odliczanieLabel);

        Scene scene = new Scene(root, 500, 300);
        stronaGlowna.setScene(scene);

        Timeline timeline = new Timeline(new KeyFrame(Duration.seconds(1), event -> {
            LocalDateTime teraz = LocalDateTime.now();
            LocalDateTime nowyRok = LocalDateTime.of(teraz.getYear() + 1, 1, 1, 0, 0, 0);

            long sekundy = ChronoUnit.SECONDS.between(teraz, nowyRok);

            long dni = sekundy / (24 * 60 * 60);
            sekundy %= (24 * 60 * 60);
            long godziny = sekundy / (60 * 60);
            sekundy %= (60 * 60);
            long minuty = sekundy / 60;
            sekundy %= 60;

            String odliczanieText = String.format("%02d dni %02d:%02d:%02d", dni, godziny, minuty, sekundy);
            odliczanieLabel.setText(odliczanieText);
        }));
        timeline.setCycleCount(Animation.INDEFINITE);
        timeline.play();

        stronaGlowna.show();
    }
}