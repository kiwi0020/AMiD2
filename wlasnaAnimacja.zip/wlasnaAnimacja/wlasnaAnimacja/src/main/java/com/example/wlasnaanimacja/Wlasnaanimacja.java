package com.example.wlasnaanimacja;

import javafx.animation.PathTransition;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.MoveTo;
import javafx.scene.shape.Path;
import javafx.scene.shape.QuadCurveTo;
import javafx.stage.Stage;
import javafx.util.Duration;

public class Wlasnaanimacja extends Application {

    @Override
    public void start(Stage scenaGlowna) {

        Circle kolo = new Circle(50, Color.LIGHTGREEN);
        kolo.setCenterX(50);
        kolo.setCenterY(50);


        Path path = new Path();
        path.getElements().add(new MoveTo(50, 50));
        path.getElements().add(new QuadCurveTo(150, 0, 250, 50));
        path.getElements().add(new QuadCurveTo(350, 100, 450, 50));


        PathTransition animacja = new PathTransition(Duration.seconds(4), path, kolo);
        animacja.setCycleCount(PathTransition.INDEFINITE);
        animacja.setAutoReverse(true);


        Pane root = new Pane(kolo);
        Scene scene = new Scene(root, 500, 200);

        scenaGlowna.setScene(scene);
        scenaGlowna.setTitle("Animacja");
        scenaGlowna.show();


        animacja.play();
    }

    public static void main(String[] args) {
        launch(args);
    }
}