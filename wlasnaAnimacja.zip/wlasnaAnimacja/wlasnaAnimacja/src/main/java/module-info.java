module com.example.wlasnaanimacja {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.wlasnaanimacja to javafx.fxml;
    exports com.example.wlasnaanimacja;
}