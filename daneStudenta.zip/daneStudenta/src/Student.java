import java.util.Scanner;
public class Student {
    private String imie;
    private String nazwisko;
    private double ocena;
    private char plec;
    private String kierunek;

    public Student(String imie, String nazwisko, double ocena, char plec, String kierunek) {
        this.imie = imie;
        this.nazwisko = nazwisko;
        this.ocena = ocena;
        this.plec = plec;
        this.kierunek = kierunek;
    }
    public void WyswietlInformacje() {
        System.out.println("Imię: " + imie);
        System.out.println("Nazwisko: " + nazwisko);
        System.out.println("Ocena: " + ocena);
        System.out.println("Płeć: " + plec);
        System.out.println("Kierunek: " + kierunek);
    }

    public void ZmienKierunek(String nowyKierunek) {
        this.kierunek = nowyKierunek;
        WyswietlInformacje();
    }
    public void ZmienOcene(double nowaOcena) {
        this.ocena = nowaOcena;
        WyswietlInformacje();
    }
    public double ObliczSredniaOcen() {
        return ocena;
    }
    public void ZmienImie(String noweImie) {
        this.imie = noweImie;
    }
    public void ZmienNazwisko(String noweNazwisko) {
        this.nazwisko = noweNazwisko;
    }
    public boolean SprawdzZaliczenie() {
        return ocena >= 2.0;
    }
    public void UstawPlec(char nowaPlec) {
        this.plec = nowaPlec;
    }

    public static double WyswietlSredniaOcenaKierunku(Student[] students, String kierunek) {
        double sumaOcen = 0;
        int iloscStudentow = 0;

        for (Student student : students) {
            if (student.kierunek.equals(kierunek)) {
                sumaOcen += student.ocena;
                iloscStudentow++;
            }
        }

        if (iloscStudentow > 0) {
            return sumaOcen / iloscStudentow;
        } else {
            return 0.0;
        }
    }

    public static void main(String[] args) {
        Student student1 = new Student("Michal", "Wedzina", 5.0, 'M', "Informatyka");
        Student student2 = new Student("Kasia", "Kowalska", 3.0, 'K', "Polski");

        student1.WyswietlInformacje();
        student1.ZmienKierunek("Elektronika");
        student1.ZmienOcene(4.0);

        student2.WyswietlInformacje();
        student2.ZmienImie("Marta");
        student2.ZmienNazwisko("Kaczmarek");

        System.out.println("Czy student1 zaliczył przedmiot? " + student1.SprawdzZaliczenie());
        System.out.println("Czy student2 zaliczył przedmiot? " + student2.SprawdzZaliczenie());

        Student[] students = {student1, student2};
        String kierunekDoObliczen = "Informatyka";
        double sredniaOcenaKierunku = Student.WyswietlSredniaOcenaKierunku(students, kierunekDoObliczen);
        System.out.println("Średnia ocena na kierunku " + kierunekDoObliczen + ": " + sredniaOcenaKierunku);
    }
}